APĪJAN SIMULATOR — ONLINE 3D ANDROID STARTER

Engine: Godot 4.3+ (GDScript)
Project folder contains:
- project.godot
- scenes/main.tscn
- scripts/main.gd
- README.txt

FEATURES IN THIS PROTOTYPE
- 3D farm, fence, trees, path, roofed pigeon loft with nest boxes and a covered animal barn
- Simple 3D pigeon models and placeholders for deer, dove, cow, goat and rabbit
- Android-friendly touch buttons
- Pigeon collection with color/rarity traits, pairing timer, eggs and hatching
- Feed shop, coins, XP, farm levels, animal happiness care, extra loft construction
- Local save file
- ENet multiplayer Host Room / Join Online controls and remote player position replication

IMPORTANT MULTIPLAYER LIMITS
This is a networking prototype, not a finished public online game. It does not yet have secure server-authoritative game state, account/login, matchmaking, chat, friend invites, anti-cheat, or cloud saves.
- For testing on one computer, run one instance as Host Room and another as Join Online using 127.0.0.1.
- For two devices on the same Wi-Fi, the client enters the host device's LAN IP, and the firewall must allow UDP port 24560.
- For play across the internet, a reachable public server is required. Hosting on a phone often fails because of carrier-grade NAT. Use a rented/cloud server or a machine with UDP port 24560 exposed and configured.
- Never share private IP/account credentials publicly. Do not assume the host button automatically creates a public internet server.

RUN
1. Download Godot 4.3 or newer: https://godotengine.org/download/
2. Extract the ZIP on a computer.
3. Import the folder containing project.godot in Godot.
4. Press Play.

ANDROID APK EXPORT
Install Godot export templates and configure Android SDK/JDK following official docs:
https://docs.godotengine.org/en/stable/tutorials/export/exporting_for_android.html
Then add an Android export preset and export a debug APK for testing.

This ZIP is source code, not a compiled APK. The project has not been built or runtime-tested in this environment. Review and test it in Godot before distributing.
