extends Node3D

# Apijan Simulator Online 3D
# Prototype: ENet host/join controls, peer position replication, pigeon breeding,
# farm progression, animal care, and simple loft construction.
# Public online play requires a reachable server IP and UDP port forwarding/hosting.

const PORT := 24560
const MAX_CLIENTS := 8
const SAVE_PATH := "user://apijan_save.json"

var coins: int = 350
var feed: int = 40
var water: int = 20
var level: int = 1
var xp: int = 0
var pigeons: Array[Dictionary] = []
var eggs: Array[Dictionary] = []
var animals: Array[Dictionary] = []
var breed_timer: float = 0.0
var breed_pair: Array[int] = []
var care_timer: float = 0.0
var message := "Welcome to Apijan Simulator! Host a room or join a friend's server."
var remote_players: Dictionary = {}
var last_sync := 0.0

var player: Node3D
var camera: Camera3D
var hud: Label
var status_label: Label
var ip_input: LineEdit
var port_input: LineEdit
var name_input: LineEdit
var player_name := "Farmer"
var loft_count := 1
var build_mode := false
var world_root: Node3D

func _ready() -> void:
    _load_save()
    _seed_animals_if_needed()
    _build_world()
    _build_player()
    _build_ui()
    _refresh_ui()
    multiplayer.peer_connected.connect(_on_peer_connected)
    multiplayer.peer_disconnected.connect(_on_peer_disconnected)
    multiplayer.connected_to_server.connect(_on_connected_to_server)
    multiplayer.connection_failed.connect(_on_connection_failed)
    multiplayer.server_disconnected.connect(_on_server_disconnected)

func _material(color: Color) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = color
    m.roughness = 0.88
    return m

func _box(parent: Node, name: String, pos: Vector3, size: Vector3, color: Color) -> MeshInstance3D:
    var n := MeshInstance3D.new()
    n.name = name
    var mesh := BoxMesh.new()
    mesh.size = size
    n.mesh = mesh
    n.material_override = _material(color)
    n.position = pos
    parent.add_child(n)
    return n

func _sphere(parent: Node, name: String, pos: Vector3, size: Vector3, color: Color) -> MeshInstance3D:
    var n := MeshInstance3D.new()
    n.name = name
    var mesh := SphereMesh.new()
    mesh.radius = 0.5
    mesh.height = 1.0
    n.mesh = mesh
    n.scale = size
    n.material_override = _material(color)
    n.position = pos
    parent.add_child(n)
    return n

func _build_world() -> void:
    world_root = Node3D.new()
    world_root.name = "FarmWorld"
    add_child(world_root)

    var world := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_SKY
    env.sky = Sky.new()
    env.sky.sky_material = ProceduralSkyMaterial.new()
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.83, 0.87, 0.92)
    env.ambient_light_energy = 0.8
    world.environment = env
    add_child(world)

    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-48, -25, 0)
    sun.light_energy = 1.2
    add_child(sun)

    _box(world_root, "Grass Farm", Vector3(0,-0.35,0), Vector3(48,0.6,48), Color(0.24,0.52,0.21))
    _box(world_root, "Dirt Path", Vector3(0,-0.02,5), Vector3(3,0.08,28), Color(0.64,0.48,0.3))
    _build_loft(Vector3(-6,0,-4), "Starter Loft")
    _build_barn(Vector3(8,0,-5))
    _build_fence()
    _build_tree(Vector3(-15,0,-10))
    _build_tree(Vector3(15,0,-12))
    _build_tree(Vector3(15,0,12))
    _build_tree(Vector3(-15,0,12))

    for i in range(pigeons.size()):
        var bird: Dictionary = pigeons[i]
        var col: Color = Color.from_string(str(bird.get("color", "#aeb7c3")), Color.GRAY)
        _build_pigeon(Vector3(-4.5 + float(i % 3) * 1.0, 0.15, -2.2 - float(i / 3) * 0.8), col, int(bird.get("id", i + 1)))

    _build_animal_model("Deer", Vector3(5,0,2), Color(0.56,0.34,0.18), Vector3(0.7,0.9,0.7))
    _build_animal_model("Cow", Vector3(10,0,2), Color(0.87,0.85,0.78), Vector3(1.0,0.8,0.85))
    _build_animal_model("Goat", Vector3(7,0,4), Color(0.55,0.48,0.38), Vector3(0.55,0.65,0.55))
    _build_animal_model("Rabbit", Vector3(3,0,5), Color(0.75,0.72,0.68), Vector3(0.35,0.35,0.35))
    _build_animal_model("Dove", Vector3(-1,0,-1), Color(0.92,0.9,0.82), Vector3(0.35,0.35,0.35))

func _build_loft(p: Vector3, label: String) -> void:
    var loft := Node3D.new()
    loft.name = label
    loft.position = p
    world_root.add_child(loft)
    _box(loft,"Floor",Vector3(0,0.12,0),Vector3(5.6,0.24,4.8),Color(0.45,0.29,0.16))
    _box(loft,"Back Wall",Vector3(0,1.4,-2.2),Vector3(5.6,2.6,0.22),Color(0.56,0.35,0.19))
    _box(loft,"Left Wall",Vector3(-2.7,1.4,0),Vector3(0.22,2.6,4.5),Color(0.56,0.35,0.19))
    _box(loft,"Right Wall",Vector3(2.7,1.4,0),Vector3(0.22,2.6,4.5),Color(0.56,0.35,0.19))
    _box(loft,"Full Roof",Vector3(0,2.8,0),Vector3(6.1,0.28,5.2),Color(0.22,0.18,0.16))
    _box(loft,"Nest Shelf",Vector3(0,0.9,-1.4),Vector3(4.1,0.16,0.35),Color(0.34,0.21,0.12))
    _box(loft,"Water Trough",Vector3(0,0.32,2.55),Vector3(1.4,0.25,0.4),Color(0.2,0.55,0.82))
    for i in range(5):
        _box(loft,"Nest Box %d" % i,Vector3(-1.6+i*0.8,1.2,-1.7),Vector3(0.62,0.55,0.52),Color(0.69,0.49,0.27))

func _build_barn(p: Vector3) -> void:
    var barn := Node3D.new()
    barn.name = "Animal Barn"
    barn.position = p
    world_root.add_child(barn)
    _box(barn,"Floor",Vector3(0,0.12,0),Vector3(5,0.24,4),Color(0.5,0.38,0.23))
    _box(barn,"Full Roof",Vector3(0,2.4,0),Vector3(5.5,0.28,4.5),Color(0.48,0.18,0.13))
    for x in [-2.1,2.1]:
        for z in [-1.6,1.6]:
            _box(barn,"Support Post",Vector3(x,1.15,z),Vector3(0.2,2.3,0.2),Color(0.35,0.22,0.13))
    _box(barn,"Feed Trough",Vector3(0,0.35,2.2),Vector3(1.6,0.3,0.35),Color(0.4,0.25,0.13))

func _build_pigeon(p: Vector3, c: Color, bird_id: int) -> void:
    var bird := Node3D.new()
    bird.name = "Pigeon_%d" % bird_id
    bird.position = p
    world_root.add_child(bird)
    _sphere(bird,"Body",Vector3(0,0.38,0),Vector3(0.5,0.36,0.75),c)
    _sphere(bird,"Head",Vector3(0,0.65,-0.34),Vector3(0.25,0.25,0.25),c)
    _box(bird,"Beak",Vector3(0,0.62,-0.58),Vector3(0.13,0.07,0.17),Color(0.95,0.63,0.18))
    _sphere(bird,"Wing",Vector3(0.2,0.4,0.03),Vector3(0.15,0.22,0.42),c.darkened(0.12))

func _build_animal_model(nm: String, p: Vector3, c: Color, s: Vector3) -> void:
    var a := Node3D.new()
    a.name = nm
    a.position = p
    a.scale = s
    world_root.add_child(a)
    _sphere(a,"Body",Vector3(0,0.6,0),Vector3(1.5,0.9,1.8),c)
    _sphere(a,"Head",Vector3(0,1.05,-0.8),Vector3(0.75,0.75,0.75),c)
    for x in [-0.48,0.48]:
        for z in [-0.6,0.6]:
            _box(a,"Leg",Vector3(x,0.2,z),Vector3(0.18,0.48,0.18),c.darkened(0.2))
    if nm == "Deer":
        _box(a,"Antler Left",Vector3(-0.2,1.62,-0.92),Vector3(0.08,0.55,0.08),Color(0.32,0.2,0.1))
        _box(a,"Antler Right",Vector3(0.2,1.62,-0.92),Vector3(0.08,0.55,0.08),Color(0.32,0.2,0.1))
    if nm == "Rabbit":
        _box(a,"Ear Left",Vector3(-0.16,1.6,-0.85),Vector3(0.12,0.55,0.12),c)
        _box(a,"Ear Right",Vector3(0.16,1.6,-0.85),Vector3(0.12,0.55,0.12),c)

func _build_tree(p: Vector3) -> void:
    _box(world_root,"Tree Trunk",p+Vector3(0,1,0),Vector3(0.45,2,0.45),Color(0.32,0.2,0.1))
    _sphere(world_root,"Tree Crown",p+Vector3(0,2.7,0),Vector3(3,3,3),Color(0.15,0.4,0.15))

func _build_fence() -> void:
    for i in range(17):
        var x := -11.0 + float(i)*1.375
        _box(world_root,"Fence Post",Vector3(x,0.48,11),Vector3(0.14,0.95,0.14),Color(0.34,0.22,0.12))
        _box(world_root,"Fence Post",Vector3(x,0.48,-11),Vector3(0.14,0.95,0.14),Color(0.34,0.22,0.12))
    for i in range(17):
        var z := -11.0 + float(i)*1.375
        _box(world_root,"Fence Post",Vector3(-11,0.48,z),Vector3(0.14,0.95,0.14),Color(0.34,0.22,0.12))
        _box(world_root,"Fence Post",Vector3(11,0.48,z),Vector3(0.14,0.95,0.14),Color(0.34,0.22,0.12))

func _build_player() -> void:
    player = Node3D.new()
    player.name = "LocalPlayer"
    player.position = Vector3(0,0.9,7)
    add_child(player)
    _sphere(player,"PlayerBody",Vector3(0,0.8,0),Vector3(0.7,1.6,0.7),Color(0.12,0.25,0.72))
    camera = Camera3D.new()
    camera.position = Vector3(0,8,12)
    camera.rotation_degrees = Vector3(-28,0,0)
    player.add_child(camera)
    camera.current = true

func _build_ui() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)

    var panel := PanelContainer.new()
    panel.position = Vector2(12,10)
    panel.custom_minimum_size = Vector2(520,150)
    layer.add_child(panel)
    var v := VBoxContainer.new()
    panel.add_child(v)
    hud = Label.new()
    hud.add_theme_font_size_override("font_size",21)
    v.add_child(hud)
    status_label = Label.new()
    status_label.add_theme_font_size_override("font_size",16)
    v.add_child(status_label)

    var connect_row := HBoxContainer.new()
    v.add_child(connect_row)
    name_input = LineEdit.new()
    name_input.placeholder_text = "Your farmer name"
    name_input.text = player_name
    name_input.custom_minimum_size = Vector2(140,36)
    connect_row.add_child(name_input)
    ip_input = LineEdit.new()
    ip_input.placeholder_text = "Server IP / hostname"
    ip_input.text = "127.0.0.1"
    ip_input.custom_minimum_size = Vector2(200,36)
    connect_row.add_child(ip_input)
    port_input = LineEdit.new()
    port_input.placeholder_text = "Port"
    port_input.text = str(PORT)
    port_input.custom_minimum_size = Vector2(70,36)
    connect_row.add_child(port_input)

    var net_row := HBoxContainer.new()
    v.add_child(net_row)
    _button(net_row,"Host Room",_host_room)
    _button(net_row,"Join Online",_join_room)
    _button(net_row,"Disconnect",_disconnect_room)

    var action_row := HBoxContainer.new()
    action_row.anchor_left=0
    action_row.anchor_top=1
    action_row.anchor_right=1
    action_row.anchor_bottom=1
    action_row.offset_left=10
    action_row.offset_top=-80
    action_row.offset_right=-10
    action_row.offset_bottom=-8
    action_row.alignment=BoxContainer.ALIGNMENT_CENTER
    layer.add_child(action_row)
    _button(action_row,"▲ Forward",func(): _move(0,-1.2))
    _button(action_row,"◀ Left",func(): _move(-1.2,0))
    _button(action_row,"▼ Back",func(): _move(0,1.2))
    _button(action_row,"Right ▶",func(): _move(1.2,0))
    _button(action_row,"Feed",_feed_birds)
    _button(action_row,"Pair",_pair_pigeons)
    _button(action_row,"Care",_care_animals)
    _button(action_row,"Build Loft",_build_extra_loft)
    _button(action_row,"Shop",_buy_feed)
    _button(action_row,"Collect",_collect_egg)

func _button(parent: Node, label: String, callback: Callable) -> void:
    var b := Button.new()
    b.text = label
    b.custom_minimum_size = Vector2(100, 48)
    b.add_theme_font_size_override("font_size", 15)
    b.pressed.connect(callback)
    parent.add_child(b)

func _host_room() -> void:
    _disconnect_room()
    var peer := ENetMultiplayerPeer.new()
    var result := peer.create_server(_get_port(), MAX_CLIENTS)
    if result != OK:
        message = "Could not host room. Port may be busy."
        _refresh_ui()
        return
    multiplayer.multiplayer_peer = peer
    player_name = name_input.text.strip_edges()
    if player_name.is_empty():
        player_name = "Farmer"
    message = "Room hosted on this device at port %d. Friends need your reachable IP." % _get_port()
    _refresh_ui()

func _join_room() -> void:
    _disconnect_room()
    player_name = name_input.text.strip_edges()
    if player_name.is_empty():
        player_name = "Farmer"
    var host := ip_input.text.strip_edges()
    if host.is_empty():
        message = "Enter the host's public IP or server hostname."
        _refresh_ui()
        return
    var peer := ENetMultiplayerPeer.new()
    var result := peer.create_client(host, _get_port())
    if result != OK:
        message = "Could not start connection. Check IP and port."
        _refresh_ui()
        return
    multiplayer.multiplayer_peer = peer
    message = "Connecting to %s:%d ..." % [host, _get_port()]
    _refresh_ui()

func _disconnect_room() -> void:
    if multiplayer.multiplayer_peer != null:
        multiplayer.multiplayer_peer.close()
        multiplayer.multiplayer_peer = OfflineMultiplayerPeer.new()
    for key in remote_players.keys():
        if is_instance_valid(remote_players[key]):
            remote_players[key].queue_free()
    remote_players.clear()
    message = "Disconnected from multiplayer."
    _refresh_ui()

func _get_port() -> int:
    var value := int(port_input.text)
    return clampi(value, 1024, 65535)

func _on_peer_connected(id: int) -> void:
    message = "Farmer connected: peer %d" % id
    _refresh_ui()

func _on_peer_disconnected(id: int) -> void:
    if remote_players.has(id):
        remote_players[id].queue_free()
        remote_players.erase(id)
    message = "Farmer %d left the farm." % id
    _refresh_ui()

func _on_connected_to_server() -> void:
    message = "Connected! Online session started."
    _refresh_ui()

func _on_connection_failed() -> void:
    message = "Connection failed. Check server address, port, firewall and internet hosting."
    _refresh_ui()

func _on_server_disconnected() -> void:
    message = "The server disconnected."
    _refresh_ui()

func _process(delta: float) -> void:
    if breed_timer > 0:
        breed_timer -= delta
        if breed_timer <= 0:
            var colors := ["#aeb7c3", "#5e6570", "#c3a27a", "#e4e2d9", "#8b9db9", "#d4c3a2"]
            var chosen := colors[randi() % colors.size()]
            var rarity := "Common"
            if randi() % 12 == 0:
                rarity = "Rare"
                chosen = "#c7a4e8"
            eggs.append({"color": chosen, "rarity": rarity, "ready": true})
            message = "%s egg laid! Tap Collect to hatch it." % rarity
            _save_game()
            _refresh_ui()

    care_timer += delta
    if care_timer >= 30.0:
        care_timer = 0.0
        for i in range(animals.size()):
            animals[i]["happiness"] = max(0, int(animals[i].get("happiness", 100)) - 1)

    last_sync += delta
    if multiplayer.multiplayer_peer != null and multiplayer.multiplayer_peer.get_connection_status() == MultiplayerPeer.CONNECTION_CONNECTED and last_sync >= 0.12:
        last_sync = 0.0
        rpc("receive_player_state", multiplayer.get_unique_id(), player_name, player.position)

@rpc("any_peer", "call_remote", "unreliable")
func receive_player_state(peer_id: int, remote_name: String, pos: Vector3) -> void:
    if peer_id == multiplayer.get_unique_id():
        return
    if not remote_players.has(peer_id):
        var avatar := Node3D.new()
        avatar.name = "RemoteFarmer_%d" % peer_id
        _sphere(avatar, "Body", Vector3(0,0.8,0), Vector3(0.7,1.6,0.7), Color(0.9,0.55,0.12))
        var tag := Label3D.new()
        tag.text = remote_name
        tag.position = Vector3(0,2.0,0)
        avatar.add_child(tag)
        add_child(avatar)
        remote_players[peer_id] = avatar
    var avatar_node: Node3D = remote_players[peer_id]
    avatar_node.position = pos

func _move(dx: float, dz: float) -> void:
    player.position.x = clampf(player.position.x + dx, -20, 20)
    player.position.z = clampf(player.position.z + dz, -20, 20)

func _feed_birds() -> void:
    if feed <= 0:
        message = "No feed left. Buy more in the shop."
    else:
        feed -= 1
        coins += 8
        xp += 10
        message = "Pigeons fed: +8 coins and +10 XP."
        _check_level()
    _save_game()
    _refresh_ui()

func _pair_pigeons() -> void:
    if pigeons.size() < 2:
        message = "You need two pigeons to pair."
    elif breed_timer > 0:
        message = "A pair is already nesting."
    else:
        breed_timer = 10.0
        message = "Pair bonded. Egg is expected in 10 seconds."
    _refresh_ui()

func _care_animals() -> void:
    water += 2
    for i in range(animals.size()):
        animals[i]["happiness"] = min(100, int(animals[i].get("happiness", 80)) + 15)
    coins = max(0, coins - 5)
    xp += 15
    message = "Animals cared for: happiness restored. Care cost 5 coins."
    _check_level()
    _save_game()
    _refresh_ui()

func _build_extra_loft() -> void:
    if coins < 150:
        message = "Extra loft costs 150 coins."
    else:
        coins -= 150
        loft_count += 1
        var p := Vector3(12,0,6 + float(loft_count)*5.5)
        _build_loft(p, "Built Loft %d" % loft_count)
        xp += 40
        message = "New roofed loft built! Farm space expanded."
        _check_level()
    _save_game()
    _refresh_ui()

func _buy_feed() -> void:
    if coins >= 25:
        coins -= 25
        feed += 15
        message = "Bought 15 feed for 25 coins."
    else:
        message = "You need 25 coins to buy feed."
    _save_game()
    _refresh_ui()

func _collect_egg() -> void:
    if eggs.size() > 0:
        var egg: Dictionary = eggs.pop_front()
        var bird_id := 1
        for b in pigeons:
            bird_id = max(bird_id, int(b.get("id", 0)) + 1)
        pigeons.append({"id": bird_id, "color": str(egg.get("color", "#c7c7c7")), "rarity": str(egg.get("rarity", "Common"))})
        coins += 20 if str(egg.get("rarity", "")) == "Rare" else 10
        xp += 25
        _build_pigeon(Vector3(-4.5 + float(pigeons.size() % 4),0.15,-4.5), Color.from_string(str(egg.get("color", "#c7c7c7")), Color.GRAY), bird_id)
        message = "%s pigeon hatched! New bird added to your collection." % str(egg.get("rarity", "Common"))
        _check_level()
    else:
        coins += 5
        message = "Farm coins collected: +5. No eggs ready yet."
    _save_game()
    _refresh_ui()

func _check_level() -> void:
    while xp >= level * 100:
        xp -= level * 100
        level += 1
        coins += 75
        message = "LEVEL UP! Farm level %d. Bonus +75 coins." % level

func _seed_animals_if_needed() -> void:
    if pigeons.is_empty():
        pigeons = [
            {"id":1,"color":"#aeb7c3","rarity":"Common"},
            {"id":2,"color":"#5e6570","rarity":"Common"},
            {"id":3,"color":"#c3a27a","rarity":"Common"},
            {"id":4,"color":"#e4e2d9","rarity":"Common"},
            {"id":5,"color":"#8b9db9","rarity":"Uncommon"},
            {"id":6,"color":"#d4c3a2","rarity":"Uncommon"}
        ]
    if animals.is_empty():
        animals = [
            {"type":"Deer","happiness":90},
            {"type":"Cow","happiness":90},
            {"type":"Goat","happiness":85},
            {"type":"Rabbit","happiness":95},
            {"type":"Dove","happiness":90}
        ]

func _refresh_ui() -> void:
    if is_instance_valid(hud):
        hud.text = "APİJAN SIMULATOR  •  Coins %d  •  Level %d  •  XP %d" % [coins, level, xp]
    if is_instance_valid(status_label):
        var net := "Offline"
        if multiplayer.multiplayer_peer != null and multiplayer.multiplayer_peer.get_connection_status() == MultiplayerPeer.CONNECTION_CONNECTED:
            net = "Connected"
        elif multiplayer.multiplayer_peer is ENetMultiplayerPeer and multiplayer.is_server():
            net = "Hosting"
        status_label.text = "Feed %d  •  Water %d  •  Pigeons %d  •  Eggs %d  •  Loft(s) %d  •  %s\n%s" % [feed, water, pigeons.size(), eggs.size(), loft_count, net, message]

func _save_game() -> void:
    var data := {
        "coins": coins, "feed": feed, "water": water, "level": level, "xp": xp,
        "pigeons": pigeons, "eggs": eggs, "animals": animals, "loft_count": loft_count
    }
    var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
    if f:
        f.store_string(JSON.stringify(data))

func _load_save() -> void:
    if not FileAccess.file_exists(SAVE_PATH):
        return
    var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
    if not f:
        return
    var parsed = JSON.parse_string(f.get_as_text())
    if typeof(parsed) != TYPE_DICTIONARY:
        return
    coins = int(parsed.get("coins", coins))
    feed = int(parsed.get("feed", feed))
    water = int(parsed.get("water", water))
    level = int(parsed.get("level", level))
    xp = int(parsed.get("xp", xp))
    pigeons.clear()
    for b in parsed.get("pigeons", []):
        if typeof(b) == TYPE_DICTIONARY:
            pigeons.append(b)
    eggs.clear()
    for e in parsed.get("eggs", []):
        if typeof(e) == TYPE_DICTIONARY:
            eggs.append(e)
    animals.clear()
    for a in parsed.get("animals", []):
        if typeof(a) == TYPE_DICTIONARY:
            animals.append(a)
    loft_count = int(parsed.get("loft_count", loft_count))
